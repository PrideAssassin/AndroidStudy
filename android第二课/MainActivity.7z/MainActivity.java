package com.pride.browser;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //获取视图组件对象
        ListView list_view=(ListView)findViewById(R.id.list_view);

        //数据源
        String [] string1={"第1行","第2行","第3行","第4行",};

        //将数据源与适配器关联
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(MainActivity.this,android.R.layout.simple_list_item_1,string1);

        //将适配器与视图关联
        list_view.setAdapter(adapter);


    }
}
